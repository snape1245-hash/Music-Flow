package com.example.kuniyo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

class ChatActivity : Activity() {
    private lateinit var et: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        val pad = (12 * resources.displayMetrics.density).toInt()
        et = EditText(this).apply {
            hint = "Kuniyo ကို ပြောမယ်…"
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        val mic = Button(this).apply { text = "🎤"; setOnClickListener { listen() } }
        val go = Button(this).apply { text = "ပို့"; setOnClickListener { send() } }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, pad, pad, pad)
            addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(mic)
            addView(go)
        }
        setContentView(row)
        et.requestFocus()
    }

    private fun send() {
        val t = et.text.toString().trim()
        if (t.isEmpty()) return
        OverlayService.instance?.say("စဉ်းစားနေတယ်…")
        Brain.ask(applicationContext, t, null) { OverlayService.instance?.say(it) }
        finish()
    }

    private fun listen() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "my-MM")
            startActivityForResult(i, 7)
        } catch (e: Exception) {
            Toast.makeText(this, "ဒီဖုန်းမှာ အသံဝင်ဖို့ မရနိုင်ဘူး", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) { et.setText(t); send() }
        }
    }
}
