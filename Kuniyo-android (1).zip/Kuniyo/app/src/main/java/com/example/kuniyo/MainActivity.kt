package com.example.kuniyo

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val REQ_PROJ = 11
    private val REQ_IDLE = 12
    private val REQ_WALK = 13

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val pad = (resources.displayMetrics.density * 20).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun btn(label: String, onClick: () -> Unit) =
            col.addView(Button(this).apply { text = label; setOnClickListener { onClick() } })

        col.addView(TextView(this).apply { text = "🐥 Kuniyo"; textSize = 28f })

        val keyBox = EditText(this).apply {
            hint = if (Prefs.key(this@MainActivity).isBlank()) "Anthropic API key (sk-ant-...)" else "API key ထည့်ပြီး ✓ (ပြောင်းချင်ရင် အသစ်ထည့်)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        col.addView(keyBox)
        btn("API key သိမ်းမယ်") {
            val k = keyBox.text.toString().trim()
            if (k.isNotEmpty()) { Prefs.setKey(this, k); keyBox.setText(""); toast("သိမ်းပြီး") }
        }

        col.addView(Switch(this).apply {
            text = "အသံထွက်ဖတ်ပေးမယ်"
            isChecked = Prefs.voice(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setVoice(this@MainActivity, v) }
        })
        col.addView(Switch(this).apply {
            text = "screen ကို ၉၀ စက္ကန့်တစ်ခါ အလိုအလျောက် ကြည့်မယ်"
            isChecked = Prefs.auto(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setAuto(this@MainActivity, v) }
        })

        btn("စတင်မယ်") { start() }
        btn("ရပ်မယ်") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Screen ကြည့်ခွင့်ပေးမယ်") {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
        }
        btn("ရပ်နေတဲ့ပုံ / GIF ရွေးမယ်") { pick(REQ_IDLE) }
        btn("လမ်းလျှောက်ပုံ / GIF ရွေးမယ်") { pick(REQ_WALK) }
        btn("Emoji 🐥 ပြန်သုံးမယ်") {
            File(filesDir, "idle.img").delete(); File(filesDir, "walk.img").delete(); reload()
        }
        col.addView(TextView(this).apply {
            text = "မှတ်ချက်: Kuniyo ကို နှိပ်ရင် စကားပြောနိုင်တယ်၊ ဖိထားရင် screen ကို ချက်ချင်းကြည့်တယ်။ " +
                "screen ကြည့်တဲ့အခါ ပုံကို Anthropic API ဆီ ပို့တာဖြစ်လို့ ကိုယ်ရေးကိုယ်တာ၊ banking app တွေပေါ်မှာ မသုံးပါနဲ့။"
            textSize = 12f
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            toast("တခြား app အပေါ်မှာ ပြခွင့်ကို ဖွင့်ပေးပါ")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
    }

    private fun pick(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, req)
    }

    private fun reload() {
        if (OverlayService.running) startService(Intent(this, OverlayService::class.java).setAction("reload"))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_PROJ -> {
                startForegroundService(
                    Intent(this, OverlayService::class.java)
                        .setAction("projection")
                        .putExtra("code", resultCode)
                        .putExtra("data", data)
                )
            }
            REQ_IDLE, REQ_WALK -> {
                val uri = data.data ?: return
                val name = if (requestCode == REQ_IDLE) "idle.img" else "walk.img"
                try {
                    contentResolver.openInputStream(uri)?.use { i ->
                        File(filesDir, name).outputStream().use { o -> i.copyTo(o) }
                    }
                    toast("ထည့်ပြီး")
                    reload()
                } catch (e: Exception) { toast("ပုံဖတ်မရဘူး") }
            }
        }
    }
}
