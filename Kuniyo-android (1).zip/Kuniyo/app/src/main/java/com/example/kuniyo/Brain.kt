package com.example.kuniyo

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    @Volatile var busy = false
    private val hist = ArrayList<Pair<String, String>>()

    private const val SYS =
        "မင်းက Kuniyo ဆိုတဲ့ ဖုန်း screen ပေါ်မှာ လျှောက်သွားနေတဲ့ ကြက်ကလေး bot ဖြစ်တယ်။ " +
        "သူငယ်ချင်းလို ကျီစယ်ပြီး ဖော်ရွေစွာ မြန်မာလို ပြောတယ်။ စာတိုတိုပဲ၊ စာကြောင်း ၁-၃ ကြောင်းအတွင်း။ " +
        "ပြောတာကို သေချာနားလည်ပြီး တိုက်ရိုက်ဖြေ။ စာရင်းမပေးနဲ့၊ emoji အနည်းငယ်ပဲသုံး။ " +
        "screen ပုံပါလာရင် အသုံးပြုသူ ဘာလုပ်နေလဲ ကြည့်ပြီး ချစ်စနိုး ဝေဖန်/မှတ်ချက်ပေး။ " +
        "password၊ ငွေကြေး၊ ကိုယ်ရေးကိုယ်တာ အချက်အလက်တွေကို ဖတ်ပြတာ မလုပ်နဲ့။"

    fun ask(ctx: Context, text: String, imageB64: String?, cb: (String) -> Unit) {
        val key = Prefs.key(ctx)
        val main = Handler(Looper.getMainLooper())
        if (key.isBlank()) { cb("API key မထည့်ရသေးဘူး၊ app ထဲမှာ အရင်ထည့်ပေးပါ"); return }
        if (busy) { cb("ခဏစောင့်ဦးနော်၊ စဉ်းစားနေတုန်း"); return }
        busy = true
        Thread {
            val out = try { call(key, text, imageB64) } catch (e: Exception) { "ချိတ်လို့မရဘူး၊ အင်တာနက်ကို စစ်ကြည့်ပါ" }
            busy = false
            main.post { cb(out) }
        }.start()
    }

    private fun call(key: String, text: String, imageB64: String?): String {
        val msgs = JSONArray()
        synchronized(hist) {
            hist.takeLast(16).forEach {
                msgs.put(JSONObject().put("role", it.first).put("content", it.second))
            }
        }
        val content: Any = if (imageB64 != null) {
            JSONArray()
                .put(JSONObject().put("type", "image").put("source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", imageB64)))
                .put(JSONObject().put("type", "text").put("text", text))
        } else text
        msgs.put(JSONObject().put("role", "user").put("content", content))

        val body = JSONObject()
            .put("model", "claude-sonnet-5-5")
            .put("max_tokens", 300)
            .put("system", SYS)
            .put("messages", msgs)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (code == 401) return "API key မမှန်ဘူးထင်တယ်"
        if (code !in 200..299) return "API error $code"

        val reply = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text").trim()
        val parts = reply.split("။").filter { it.isNotBlank() }
        val short = if (parts.size > 3) parts.take(3).joinToString("။") + "။" else reply
        synchronized(hist) {
            hist.add("user" to (if (imageB64 != null) "[screen ကြည့်ပြီး မှတ်ချက်တောင်းတယ်]" else text))
            hist.add("assistant" to short)
        }
        return short
    }
}
