package com.example.kuniyo

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.animation.doOnEnd
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

class OverlayService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var instance: OverlayService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var box: FrameLayout
    private lateinit var emoji: TextView
    private lateinit var img: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private var viewAdded = false

    private val h = Handler(Looper.getMainLooper())
    private var anim: ValueAnimator? = null
    private var dragging = false

    private var idleD: Drawable? = null
    private var walkD: Drawable? = null

    private var tts: TextToSpeech? = null
    private var ttsOk = false

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastB64: String? = null

    private val hideRun = Runnable { bubble.visibility = View.INVISIBLE }
    private val walkRun = Runnable { walk() }
    private val autoRun = object : Runnable {
        override fun run() {
            if (projection != null) {
                if (Prefs.auto(this@OverlayService) && !dragging && !Brain.busy) peek()
                h.postDelayed(this, 90000)
            }
        }
    }

    private val lines = listOf(
        "ဘာလုပ်နေတာလဲ?", "ငါ့ကို မကြည့်ဘူးလား", "ဟိတ်! ဒီမှာ ပြောနေတာ",
        "ဖုန်းကို ခဏနားပေးဦးလေ", "ဒီနေ့ ရေသောက်ပြီးပြီလား",
        "လျှောက်လည်နေတာ~", "ငါ့ကို နှိပ်ပြီး စကားပြောလေ"
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "reload" -> if (viewAdded) loadImages()
            "peek" -> peek()
            "projection" -> {
                val code = intent.getIntExtra("code", 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra("data", Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
                if (data != null && viewAdded) setupProjection(code, data)
            }
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        instance = this
        startAsForeground(false)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildView()
        loadImages()
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("my", "MM"))
                ttsOk = r != null && r >= TextToSpeech.LANG_AVAILABLE
            }
        }
        h.postDelayed({ say("မင်္ဂလာပါ၊ Kuniyo ပါ!"); h.postDelayed(walkRun, 2500) }, 800)
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kuniyo", "Kuniyo", NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, "kuniyo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Kuniyo လျှောက်လည်နေတယ်")
            .setOngoing(true)
            .build()
    }

    private fun startAsForeground(withProjection: Boolean) {
        var type = 0
        if (Build.VERSION.SDK_INT >= 34) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else if (Build.VERSION.SDK_INT >= 29 && withProjection) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        ServiceCompat.startForeground(this, 1, notif(), type)
    }

    // ---------- view ----------
    private fun buildView() {
        val d = resources.displayMetrics.density
        bubble = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.BLACK)
            setPadding(24, 12, 24, 12)
            maxWidth = (d * 200).toInt()
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 36f }
            visibility = View.INVISIBLE
        }
        emoji = TextView(this).apply { text = "🐥"; textSize = 44f }
        img = ImageView(this).apply {
            adjustViewBounds = true
            maxWidth = (d * 90).toInt()
            visibility = View.GONE
        }
        box = FrameLayout(this).apply {
            addView(emoji)
            addView(img, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, (d * 64).toInt()))
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble)
            addView(box)
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 50; y = 300 }

        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            var moved = false; var longDone = false
            val longRun = Runnable { longDone = true; peek() }
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                        moved = false; longDone = false; dragging = true
                        h.removeCallbacks(walkRun); anim?.cancel()
                        h.postDelayed(longRun, 700)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        if (abs(dx) + abs(dy) > 10) { moved = true; h.removeCallbacks(longRun) }
                        lp.x = ox + dx; lp.y = oy + dy
                        wm.updateViewLayout(root, lp)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        h.removeCallbacks(longRun)
                        dragging = false
                        if (!moved && !longDone) openChat()
                        h.postDelayed(walkRun, 3000)
                    }
                }
                return true
            }
        })
        wm.addView(root, lp)
        viewAdded = true
    }

    private fun openChat() {
        startActivity(Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- character image / gif ----------
    private fun load(name: String): Drawable? {
        val f = File(filesDir, name)
        if (!f.exists()) return null
        return try { ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) } catch (e: Exception) { null }
    }

    private fun loadImages() {
        idleD = load("idle.img")
        walkD = load("walk.img")
        if (idleD == null) idleD = walkD
        if (walkD == null) walkD = idleD
        setFace(idleD)
    }

    private fun setFace(d: Drawable?) {
        if (d == null) {
            img.visibility = View.GONE; emoji.visibility = View.VISIBLE
        } else {
            emoji.visibility = View.GONE; img.visibility = View.VISIBLE
            img.setImageDrawable(d)
            (d as? AnimatedImageDrawable)?.let {
                it.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                it.start()
            }
        }
    }

    // ---------- speech ----------
    fun say(t: String) {
        bubble.text = t
        bubble.visibility = View.VISIBLE
        h.removeCallbacks(hideRun)
        h.postDelayed(hideRun, 3500 + t.length * 60L)
        if (Prefs.voice(this) && ttsOk) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "k")
    }

    // ---------- screen watching ----------
    private fun setupProjection(code: Int, data: Intent) {
        startAsForeground(true)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        vd?.release(); reader?.close(); projection?.stop()
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                vd?.release(); vd = null
                reader?.close(); reader = null
                projection = null
            }
        }, h)
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.4f).toInt()
        val hh = (dm.heightPixels * 0.4f).toInt()
        val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
        vd = p.createVirtualDisplay(
            "kuniyo", w, hh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h
        )
        reader = r
        projection = p
        say("ဟိ၊ အခု screen ကို ကြည့်လို့ရပြီ!")
        h.removeCallbacks(autoRun)
        h.postDelayed(autoRun, 90000)
    }

    private fun grabB64(): String? {
        val r = reader ?: return null
        val im = r.acquireLatestImage()
        if (im != null) {
            try {
                val pl = im.planes[0]
                val rowPad = pl.rowStride - pl.pixelStride * im.width
                val bmp = Bitmap.createBitmap(im.width + rowPad / pl.pixelStride, im.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(pl.buffer)
                val crop = Bitmap.createBitmap(bmp, 0, 0, im.width, im.height)
                val bos = ByteArrayOutputStream()
                crop.compress(Bitmap.CompressFormat.JPEG, 60, bos)
                lastB64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            } finally { im.close() }
        }
        return lastB64
    }

    private fun peek() {
        val b64 = grabB64()
        if (b64 == null) { say("screen ကြည့်ခွင့် မပေးရသေးဘူး၊ app ထဲမှာ ပေးပါ"); return }
        say("ကြည့်နေတယ်…")
        Brain.ask(this, "(ခုပဲ screen ကို ကြည့်လိုက်တယ်၊ ဘာလုပ်နေလဲ မှတ်ချက်ပေး)", b64) { say(it) }
    }

    // ---------- walking ----------
    private fun walk() {
        if (dragging || !viewAdded) return
        val dm = resources.displayMetrics
        val tx = Random.nextInt(0, (dm.widthPixels - root.width).coerceAtLeast(1))
        val ty = Random.nextInt(dm.heightPixels / 8, dm.heightPixels * 3 / 4)
        val sx = lp.x; val sy = lp.y
        box.scaleX = if (tx < sx) -1f else 1f
        setFace(walkD)
        val dist = hypot((tx - sx).toFloat(), (ty - sy).toFloat())
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = (dist / 0.25f).toLong().coerceAtLeast(500L)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                lp.x = (sx + (tx - sx) * t).toInt()
                lp.y = (sy + (ty - sy) * t).toInt()
                box.translationY = -abs(sin(t * dist / 60f * PI.toFloat())) * 12f
                if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
            }
            doOnEnd {
                box.translationY = 0f
                if (!dragging) {
                    setFace(idleD)
                    if (Random.nextFloat() < 0.6f) say(lines.random())
                    h.postDelayed(walkRun, 2000L + Random.nextLong(2000L))
                }
            }
            start()
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        anim?.cancel()
        vd?.release(); reader?.close(); projection?.stop()
        tts?.shutdown()
        if (viewAdded && root.isAttachedToWindow) wm.removeView(root)
        running = false
        instance = null
        super.onDestroy()
    }
}
