package com.example.kuniyo

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("kuniyo", Context.MODE_PRIVATE)
    fun key(c: Context): String = p(c).getString("key", "") ?: ""
    fun setKey(c: Context, v: String) = p(c).edit().putString("key", v).apply()
    fun voice(c: Context) = p(c).getBoolean("voice", false)
    fun setVoice(c: Context, v: Boolean) = p(c).edit().putBoolean("voice", v).apply()
    fun auto(c: Context) = p(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) = p(c).edit().putBoolean("auto", v).apply()
}
