Kuniyo – Android overlay bot (v2)

APK ထုတ်နည်း
1. Android Studio install လုပ် (developer.android.com/studio)
2. Open > ဒီ Kuniyo folder ကိုရွေး > Gradle sync ပြီးအောင်စောင့် (အင်တာနက်လို)
3. Build > Build APK(s)
4. app/build/outputs/apk/debug/app-debug.apk ကို ဖုန်းထဲပို့ install (unknown sources ခွင့်ပြု)

သုံးနည်း
1. App ဖွင့် > Anthropic API key ထည့်သိမ်း (console.anthropic.com က ယူ၊ အသုံးစရိတ်ကျသင့်မယ်)
2. "စတင်မယ်" > overlay ခွင့်ဖွင့် > ပြန်လာပြီး "စတင်မယ်" ထပ်နှိပ်
3. "Screen ကြည့်ခွင့်ပေးမယ်" နှိပ် (service ရပ်/restart လုပ်တိုင်း ပြန်ပေးရမယ်)
4. Kuniyo ကိုနှိပ် = စကားပြော (🎤 နဲ့ အသံလည်းရ) / ဖိထား = screen ကြည့်ပြီး မှတ်ချက်
5. ရပ်နေတဲ့ပုံ / လမ်းလျှောက်ပုံ / GIF ရွေးပြီး character ပြောင်း

သတိ
- screen ကြည့်တဲ့ပုံ၊ စာတွေကို Anthropic API ဆီ ပို့တယ်။ banking/password မျက်နှာပြင်တွေမှာ မသုံးနဲ့
- မြန်မာအသံထွက်က ဖုန်းမှာ Google TTS မြန်မာအသံ ရှိမှ အလုပ်လုပ်မယ်
- API key ကို ဖုန်းထဲမှာပဲ သိမ်းတယ်၊ APK ကို တခြားသူဆီ မဝေနဲ့
