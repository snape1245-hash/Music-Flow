package com.musicflow.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object St {
    var title = ""
    var artist = ""
    var cover: Bitmap? = null
    var playing = false
    var l1 = ""
    var l2 = ""
    var floatOn = false
    var visible = true
}

class PlayerService : Service() {
    companion object {
        var inst: PlayerService? = null
    }

    private lateinit var nm: NotificationManager
    private lateinit var session: MediaSession
    private val ui = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var mini = false
    private var parts: List<View> = emptyList()
    private lateinit var iv: ImageView
    private lateinit var tTitle: TextView
    private lateinit var tArtist: TextView
    private lateinit var t1: TextView
    private lateinit var t2: TextView
    private lateinit var btnPlay: ImageButton

    private val rec = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val a = i?.action ?: return
            MainActivity.cmd(a.removePrefix("mf."))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        inst = this
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("player", "Music Flow", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "MusicFlow")
        session.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { MainActivity.cmd("toggle") }
            override fun onPause() { MainActivity.cmd("toggle") }
            override fun onSkipToNext() { MainActivity.cmd("next") }
            override fun onSkipToPrevious() { MainActivity.cmd("prev") }
        })
        session.isActive = true
        val f = IntentFilter()
        f.addAction("mf.prev")
        f.addAction("mf.toggle")
        f.addAction("mf.next")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rec, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rec, f)
        startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        refresh()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        try { root?.let { wm?.removeView(it) } } catch (e: Exception) { }
        root = null
        try { unregisterReceiver(rec) } catch (e: Exception) { }
        session.release()
        inst = null
        super.onDestroy()
    }

    private fun pi(a: String): PendingIntent =
        PendingIntent.getBroadcast(this, a.hashCode(), Intent(a).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun act(res: Int, label: String, a: String): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, res), label, pi(a)).build()

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, "player")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(if (St.title.isEmpty()) "Music Flow" else St.title)
            .setContentText(if (St.artist.isEmpty()) St.l1 else St.artist)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .addAction(act(android.R.drawable.ic_media_previous, "Previous", "mf.prev"))
            .addAction(act(if (St.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause", "mf.toggle"))
            .addAction(act(android.R.drawable.ic_media_next, "Next", "mf.next"))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
        val c = St.cover
        if (c != null) b.setLargeIcon(c)
        return b.build()
    }

    fun refresh() {
        ui.post {
            val md = MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, St.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, St.artist)
            val c = St.cover
            if (c != null) md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, c)
            session.setMetadata(md.build())
            session.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS
                    )
                    .setState(
                        if (St.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f
                    ).build()
            )
            nm.notify(1, notif())
            overlay()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(sp: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = sp
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        return t
    }

    private fun ib(res: Int, a: String): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.background = null
        b.setOnClickListener { MainActivity.cmd(a) }
        return b
    }

    private fun overlay() {
        val want = St.floatOn && !St.visible && Settings.canDrawOverlays(this)
        if (want && root == null) build()
        if (!want) {
            root?.let { try { wm?.removeView(it) } catch (e: Exception) { } }
            root = null
        }
        if (root != null) fill()
    }

    private fun fill() {
        val cv = St.cover
        if (cv != null) iv.setImageBitmap(cv) else iv.setImageDrawable(null)
        tTitle.text = if (St.title.isEmpty()) "Music Flow" else St.title
        tArtist.text = St.artist
        t1.text = St.l1
        t2.text = St.l2
        btnPlay.setImageResource(if (St.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }

    private fun setMini(v: Boolean) {
        mini = v
        val vis = if (v) View.GONE else View.VISIBLE
        parts.forEach { it.visibility = vis }
        val s = if (v) dp(52) else dp(44)
        val l = iv.layoutParams as LinearLayout.LayoutParams
        l.width = s
        l.height = s
        iv.layoutParams = l
        iv.invalidateOutline()
        lp?.width = if (v) WindowManager.LayoutParams.WRAP_CONTENT else dp(300)
        val r = root
        val l2 = lp
        if (r != null && l2 != null) {
            try { wm?.updateViewLayout(r, l2) } catch (e: Exception) { }
        }
    }

    private fun build() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(12), dp(12), dp(12), dp(8))
        val bg = GradientDrawable()
        bg.setColor(0xE6101016.toInt())
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), 0x24FFFFFF)
        r.background = bg

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(0xFF1A1A20.toInt())
        iv.clipToOutline = true
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, if (mini) v.width / 2f else dp(12).toFloat())
            }
        }
        head.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        tTitle = tv(15f, true)
        tArtist = tv(12f, false)
        tArtist.alpha = 0.6f
        col.addView(tTitle)
        col.addView(tArtist)
        val cp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        cp.leftMargin = dp(10)
        head.addView(col, cp)
        val mn = tv(20f, true)
        mn.text = "\u2013"
        mn.setPadding(dp(10), 0, dp(10), 0)
        mn.setOnClickListener { setMini(true) }
        val cl = tv(18f, true)
        cl.text = "\u2715"
        cl.setPadding(dp(10), 0, dp(6), 0)
        cl.setOnClickListener {
            St.floatOn = false
            overlay()
        }
        head.addView(mn)
        head.addView(cl)

        t1 = tv(18f, true)
        t1.maxLines = 3
        t1.setPadding(dp(4), dp(12), dp(4), dp(4))
        t2 = tv(14f, true)
        t2.alpha = 0.4f
        t2.setPadding(dp(4), 0, dp(4), dp(4))

        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER
        btnPlay = ImageButton(this)
        btnPlay.setColorFilter(Color.BLACK)
        val pbg = GradientDrawable()
        pbg.shape = GradientDrawable.OVAL
        pbg.setColor(Color.WHITE)
        btnPlay.background = pbg
        btnPlay.setOnClickListener { MainActivity.cmd("toggle") }
        ctl.addView(ib(android.R.drawable.ic_media_previous, "prev"), LinearLayout.LayoutParams(dp(44), dp(44)))
        val pl = LinearLayout.LayoutParams(dp(46), dp(46))
        pl.setMargins(dp(14), 0, dp(14), 0)
        ctl.addView(btnPlay, pl)
        ctl.addView(ib(android.R.drawable.ic_media_next, "next"), LinearLayout.LayoutParams(dp(44), dp(44)))

        r.addView(head)
        r.addView(t1)
        r.addView(t2)
        r.addView(ctl)
        parts = listOf(col, mn, cl, t1, t2, ctl)

        val p = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(40)
        p.y = dp(120)
        lp = p
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) + Math.abs(e.rawY - dy) > dp(6)) moved = true
                    p.x = sx + (e.rawX - dx).toInt()
                    p.y = sy + (e.rawY - dy).toInt()
                    try { wm?.updateViewLayout(r, p) } catch (x: Exception) { }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && mini) setMini(false)
                }
            }
            true
        }
        mini = false
        wm?.addView(r, p)
        root = r
    }
}
