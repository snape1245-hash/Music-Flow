package com.musicflow.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        var web: WebView? = null
        fun cmd(c: String) {
            web?.post { web?.evaluateJavascript("window.nativeCmd&&nativeCmd('" + c + "')", null) }
        }
    }

    private var chooser: ValueCallback<Array<Uri>>? = null
    private var saveUri: Uri? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val w = WebView(this)
        web = w
        w.setBackgroundColor(Color.BLACK)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(Bridge(), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (r.url.host == "musicflow.local") {
                    val p = r.url.path.orEmpty().trimStart('/').ifEmpty { "index.html" }
                    return try {
                        WebResourceResponse("text/html", "utf-8", assets.open(p))
                    } catch (e: Exception) {
                        null
                    }
                }
                return null
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView,
                cb: ValueCallback<Array<Uri>>,
                p: WebChromeClient.FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                return try {
                    startActivityForResult(p.createIntent(), 1)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        setContentView(w)
        w.loadUrl("https://musicflow.local/index.html")
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 1) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d))
            chooser = null
        } else {
            super.onActivityResult(rc, res, d)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val js = "(function(){var n=document.getElementById('np');if(n&&n.classList.contains('on')){n.classList.remove('on');return 1}return 0})()"
        web?.evaluateJavascript(js) { r -> if (r != "1") moveTaskToBack(true) }
    }

    override fun onStart() {
        super.onStart()
        St.visible = true
        PlayerService.inst?.refresh()
    }

    override fun onStop() {
        super.onStop()
        St.visible = false
        PlayerService.inst?.refresh()
    }

    override fun onDestroy() {
        if (isFinishing) {
            stopService(Intent(this, PlayerService::class.java))
            web = null
        }
        super.onDestroy()
    }

    private fun push() {
        val s = PlayerService.inst
        if (s != null) {
            s.refresh()
        } else {
            try {
                startForegroundService(Intent(this, PlayerService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun nowPlaying(t: String, a: String, b64: String) {
            St.title = t
            St.artist = a
            St.cover = if (b64.isEmpty()) null else try {
                val d = Base64.decode(b64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(d, 0, d.size)
            } catch (e: Exception) {
                null
            }
            push()
        }

        @JavascriptInterface
        fun setPlaying(p: Boolean) {
            St.playing = p
            push()
        }

        @JavascriptInterface
        fun setLines(a: String, b: String) {
            St.l1 = a
            St.l2 = b
            push()
        }

        @JavascriptInterface
        fun toggleFloat(): Boolean {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Allow \"Display over other apps\" for Music Flow, then come back", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
                }
                return false
            }
            St.floatOn = !St.floatOn
            push()
            runOnUiThread {
                Toast.makeText(
                    this@MainActivity,
                    if (St.floatOn) "Floating window on. Leave the app to see it." else "Floating window off",
                    Toast.LENGTH_SHORT
                ).show()
            }
            return St.floatOn
        }

        @JavascriptInterface
        fun saveChunk(name: String, b64: String, first: Boolean) {
            try {
                val data = Base64.decode(b64, Base64.DEFAULT)
                if (first) {
                    val v = ContentValues()
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name)
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    v.put(MediaStore.Downloads.IS_PENDING, 1)
                    saveUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                }
                val u = saveUri ?: return
                contentResolver.openOutputStream(u, if (first) "w" else "wa")?.use { it.write(data) }
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun saveDone(name: String) {
            try {
                val u = saveUri
                if (u != null) {
                    val v = ContentValues()
                    v.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(u, v, null, null)
                }
            } catch (e: Exception) {
            }
            saveUri = null
        }
    }
}
